# Importa a classe Flask do flask, que é usada para criar a aplicação WEB
from flask import Flask
from flask_jwt_extended import JWTManager
# Importa a função initi_db do arquivo database.db, que inicializa o banco de dados.
from database.db import init_db
# Importa o blueprint de upload di arquivo upload_route ( ele contém as rotas de download)
from routes.user_routes import user_bp
# Importa o blueprint de download do arquivo download_route ( ele contém as rotas de download)
from routes.formulario_routes import formulario_bp

 
# Cria a aplicação Flask
app = Flask(__name__)
 
app.config.from_pyfile('config.py')

jwt = JWTManager(app)

# define o nome da pasta opnde os arquivos enviados serão armazenados
# UPLOAD_FOLDER = 'uploads'
 
# Configura o Flask para usar essa pasta de uploads
#app.config['UPLOD_FOLDER'] = UPLOAD_FOLDER
 
# Verifica se a pasta de uploads existe
#if not os.path.exists(UPLOAD_FOLDER):
    # Se a pasta não existir, Cria a pasta
   # os.makedir(UPLOAD_FOLDER)
# Inicializa o banco de dados chamando a função init_db()
init_db()
 
# Adiciona as rotas de upload na aplicação, todas as URLs dessa rotas vão começar com "/uploads"
app.register_blueprint(user_bp, url_prefix='/users')
# Adiciona as rotas de download na aplicação, todas as URLs dessas rotas vão começar com "/downloads"
app.register_blueprint(formulario_bp, url_prefix='/formularios')
# Verifica se o script está sendo executado diretamente
if __name__ == '__main__':
    # Inicia o servidor Flask no mode debug ( para mostar erros no terminal)
    app.run(debug=True)