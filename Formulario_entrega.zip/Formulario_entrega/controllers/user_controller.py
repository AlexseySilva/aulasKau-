from werkzeug.security import generate_password_hash, check_password_hash
from flask_jwt_extended import create_access_token
from models.user_model import UserModel

class UserController:
    @staticmethod
    def register_user(data):
        username = data.get('username')
        password = data.get('password')

        if not username or not password:
            return {"error": "Nome de usuario e senha sao obrigatorios"}, 400
        
        hashed_password = generate_password_hash(password)

        if UserModel.create_user(username, hashed_password):
            return {"message": "Usuario registrado com sucesso"}, 201
        
        return {"error": "Nome de usuario ja existe"}, 400

# Metodo estatico para fazer o login de um usuario
@staticmethod
def login_user(data):
    username = data.get('username') # Nome do usuario
    password = data.get('password') # senha do usuario

    # Verifica se o nome de usuario e a senha foram fornecidas
    if not username or not password:
        return {"error": "Nome de usuario e senha são obrigatorios"}, 400
    
    # Busca o usuario no banco de dados pelo nome de usuario
    user = UserModel.find_by_username(username)
    if user and check_password_hash(user['password'], password): # Verifica se a senha é valida
        access_token = create_access_token(identity=str(user['id'])) # Cria um token JWT com o ID do usuario
        return {"access_token": access_token}, 200 # Retorna o token de acesso
    
    return {"error": "Nome de usuario ou senha invalidos"}, 401 # Retorna erro se as credenciais forem invalidas

# Metodo estatico para obter os dados de um usuario
@staticmethod
def get_user(user_id):
    user = UserModel.find_by_id(user_id) # Busca o usuario pelo ID.
    if user:
        return {"id": user['id'], "username": user['username']}, 200
    return {"error": "Usuario nã encontrado"}, 404

# Metodo estatico para atualizar os dados de um usuario
@staticmethod
def update_user(user_id, data):
    username = data.get('username') # nome de usuario dos dados fornecidos
    password = data.get('password') # senha dos dados fornecidos

    # Verifica se pelo menos um campo foi fornecido para atualização
    if not username and not password:
        return {"error": "Informe ao menos um cmapo para atualizar"}, 400
    
    # Gere um hash para a senha se a senha for fornecida
    hashed_password = generate_password_hash(password) if password else None
    # Atualiza o usuario no banco de dados
    UserModel.update_user(user_id, username, hashed_password)

    return {"message": "Usuario atualizado com sucesso"}, 200

# Metodo estatica para excluir um usuario
@staticmethod
def delete_user(user_id):
    UserModel.delete_user(user_id)
    return {"message": "Usuario deleteado com sucesso"}, 200