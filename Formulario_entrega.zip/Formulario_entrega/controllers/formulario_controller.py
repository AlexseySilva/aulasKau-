from models.formulario_model import FormularioModel # Importa o modelo FormularioModel para interagir com o banco de dados
from flask import jsonify # Importa jsonify para criar respostas JSOn

class FormularioController:
    # Metodo estatico para criar um novo formulario
    @staticmethod
    def create_formulario(user_id, data):
        nome = data.get('nome') # Obtém o nome do formulário dos dados fornecidos
        email = data.get('email') # Obtém o email do formulario
        data_nascimento = data.get('data_nascimento')  # Obtém a data de nascimento do foormula´rio
        cpf = data.get('cpf')# Obtem o CPF do formulário
        genero = data.get('genero') # Obtem o gênero do formulario

        # Verifica se todos os campos obrigatorios foram fornecidos
        if not nome or not email or not data_nascimento or not cpf or not genero:
            return{"error": "Todos os campos são obrigatorios"}, 400
        
        # Chama o metodo do modelo para criar o formulario no banco de dados
        formulario = FormularioModel.create_formulario(user_id, nome, email, data_nascimento, cpf, genero) 
        if formulario:
            return {"message": "Formulario criado com sucesso"}, 201 # Retorna sucesso se o formulário for criado
        return {"error": "Erro ao criar formulario"}, 500 # Retorna erro se houver falaha na criação


    # Metodo estatico para obter um formulario associado ao usuario
    @staticmethod
    def get_formulario(user_id):
        # Busca o formulario no banco de dados usando o ID do usuario
        formulario = FormularioModel.find_by_user_id(user_id)
        if formulario:
            return {"id": formulario['id'], "nome": formulario['nome'], "email": formulario['email'],
                    "data_nascimento": formulario['data_nascimento'], "cpf": formulario['cpf'],
                    "genero": formulario['genero']}, 200 # Retorna os dados do formulario encontrado
        return {"error": "Formulario não encontrado"}, 400 

    # Metodo estatico para atualizar um formulario existent
    @staticmethod
    def update_formulario(user_id, formulario_id, data):
        # Busca o formulario pelo ID fornecido
        formulario = FormularioModel.find_by_id(formulario_id)

        # Verifica se o formulario existe e se pertence ao usuario
        if not formulario or formulario['user_id'] != user_id:
            return {"error": "Formulario não encontrado ou não autorizado"}, 400

        # Obtem os novos dados do formulario ou mantem os valores antigos
        nome = data.get('nome', formulario['nome'])
        email = data.get('email', formulario['email'])
        data_nascimento = data.get('data_nascimento', formulario['data_nascimento'])
        cpf = data.get('cpf', formulario['cpf'])
        genero =  data.get('genero', formulario['genero'])

        FormularioModel.update_formulario(formulario_id, nome, email, data_nascimento, cpf, genero)
        return {"message": "Formulario atualizado com sucesso"}, 200

    # Metodo estatico para excluir um formulario existente
    @staticmethod
    def delete_funcionario(user_id, formulario_id):
        # Busca o formulario pelo ID fornecido
        formulario = FormularioModel.find_by_id(formulario_id)
        
        # Verifica se o formulario existe e se pertence ao usuario
        if not formulario or formulario['user_id'] != user_id:
            return {"error": "Formulario não encontrado ou não autorizado"}, 404

        # Chama o metodo do modelo para excluir o formulario do banco de dados
        FormularioModel.delete_funcionario(formulario_id)
        return {"message": "Formulario deletado com sucesso"}, 200