SECRET_KEY ='your-secrer-key' # define uma chave secreta para proteger sessões ou dados sensíveis
JWT_SECRETE_KEY = SECRET_KEY # Usando a mesma chave secreta para assinar os tokebs JWT.
DATABASE = ' database.bd' # Definindo o nome do arquivo do banco de dados SQLite.