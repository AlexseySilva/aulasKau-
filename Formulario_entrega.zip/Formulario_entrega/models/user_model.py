import sqlite3
from database.db import get_db_connection

class UserModel:
    @staticmethod
    def find_by_usernam(username):
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ?', (username)).fetchone()
        conn.close()
        return user
    
    # Metodo estatico para buscar um usuario pelo ID
    @staticmethod
    def find_by_id(user_id):
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ?', (user_id)).fetchone()
        return user
    
    # Metodo estatico para criar um novo usuario
    @staticmethod
    def create_user(username, password):
        conn = get_db_connection()
        try:
            conn.execute('INSERT INTO users (username, password) VALUES (?,?)', (username, password))
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            return None
        finally:
            conn.close()

    # Metodo estatico para atualizar os dados de um usuario
    def update_user(user_id, username=None, password=None):
        conn = get_db_connection()

        if username:
            conn.execute('UPDATE users SET username = ? WHERE id = ?', (username, user_id))
        if password:
            conn.execute('UPDATE users SET password = ? WHERE id = ?', (password, user_id))
        
        conn.commit()
        conn.close()

    # Metodo estatico para excluir um usuario
    @staticmethod
    def delete_user(user_id):
        conn = get_db_connection()
        conn.execute('DELETE FROM users WHERE id = ?', (user_id))
        conn.commit()
        conn.close()