import sqlite3
from database.db import get_db_connection

class FormularioModel:
    # Metodo estatico para criar um novo formulario
    @staticmethod
    def create_formulario(user_id, nome, email, data_nscimento, cpf, genero):
        conn = get_db_connection() # Obtem uma conexão com o banco de dados
        try:
            # Executa a inserção de um novo formulario na tabela 'formulario'
            conn.execute('''INSERT INTO formulario (user_id, nome, email, data_nascimento, cpf, genero)'
                                VALUES (?, ?, ?, ?, ?, ?)''',
                        (user_id, nome, email, data_nscimento, cpf, genero))
            conn.commit() # Comfirma a transação
            return True
        except sqlite3.IntegrityError:
            return None 
        finally:
            conn.close()

    # Metodo estatico para buscar um formulario pelo ID do usuario
    @staticmethod
    def find_by_user_id(user_id):
        conn = get_db_connection() # Obtem uma conexão com o banco de dados
        # Executa uma consulta SQL para buscar o formulario do usuario pelo ID
        formulario = conn.execute('SELECT * FROM formulario WHERE user_id = ?', (user_id)).fetchone()
        conn.close() 
        return formulario
    
    # Metodo estatico para buscar um formulario pelo seu ID
    @staticmethod
    def find_by_id(formulario_id):
        conn = get_db_connection() # Obtem uma conexão com o banco de dados
        # Executa uma consulta SQL para buscar o formulario pelo ID forncido
        formulario = conn.execute('SELECT * FROM formulario WHERE id = ?', (formulario_id)).fetchone()
        conn.close() # Fecha a conexão com o banco de dados
        return formulario # Retorna o formulario encontrado (ou None, se não encontrado)
    
    # Metodo estatico para atualizar um formulario existente
    @staticmethod
    def update_formulario(formulario_id, nome, email, data_nascimento, cpf, genero):
        conn = get_db_connection() # Obtem uma conexão com o banco de dados
        # Executa a atualização do formulario com os novos dados
        conn.execute('''UPDATE formulario SET nome = ?, data_nascimento = ?, cpf = ?, genero = ?'
                            WHERE id = ? ''',
                    (nome, email, data_nascimento, cpf, genero, formulario_id))
        conn.commit() # Confirma a transação
        conn.close() # Fecha a conexão com o banco de dados

    # Metodo estatico para excluir um formulario pelo seu ID
    @staticmethod
    def delete_formulario(formulario_id):
        conn = get_db_connection()
        # Executa a exclusão do formulario com o ID fornecido
        conn.execute('DELETE FROM formulario WHERE id = ?', (formulario_id))
        conn.commit()
        conn.close()