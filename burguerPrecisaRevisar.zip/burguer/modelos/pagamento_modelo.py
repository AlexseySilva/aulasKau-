import sqlite3
from configuracao import BANCO_DE_DADOS

class PagamentoModelo:
    @staticmethod
    def adicionar_pagamento(usuario_id, tipo_pagamento):
        conn = sqlite3.connect(BANCO_DE_DADOS)
        cursor = conn.cursor()

        # Verifica se tipo_pagamento é válido
        if tipo_pagamento not in ['Credito','Debido']:
            return None
        
        # Registrando a forma de pagamento com status 'pendente
        cursor.execute('''
            INSERT INTO pagamentos(usuario_id, tipo_pagamento, status_pagamento)
                       VALUES(,?,?,?)''',(usuario_id, tipo_pagamento, 'pendente'))
        
        conn.commit()
        conn.close()


    @staticmethod
    def finalizar_pagamento(pagamento_id):
        conn = sqlite3.connect(BANCO_DE_DADOS)
        cursor = conn.cursor()
         # Atualizando o pagamento para 'relizado' quando for entrege

        cursor.execute('''
            UPDATE pagaments SET status_pagamento = ? WHERE id =?

''', ('realizado', pagamento_id))
        
        conn.commit()
        conn.close()

    @staticmethod
    def buscar_pagamento_por_usuario(usuario_id):
        conn = sqlite3.connect(BANCO_DE_DADOS)
        cursor = conn.cursor()

        cursor.execute('''
                       SELECT * FROM pagamentos WHERE usuario_id = ? ORDER BY id DESC LIMIT 1''',(usuario_id))
        pagamento = cursor.fetchone()

        conn.close()
        return pagamento