import sqlite3
from configuracao import BANCO_DE_DADOS

class EnderecoModelo:

    @staticmethod
    def adicionar_endereco(usuario_id,rua, numero, bairro, cidade, estado,cep):
        try:
            conn = sqlite3.connect(BANCO_DE_DADOS)
            cursor = conn.cursor()

            cursor.execute('''
                INSERT INTO enderecos (usuario_id, rua, numero, bairro, cidade, estado, cep)
                VALUES (?,?,?,?,?,?,?)
                ''', (usuario_id,rua, numero, bairro, cidade, estado,cep))
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"erro ao adicionar endereco:{e}")