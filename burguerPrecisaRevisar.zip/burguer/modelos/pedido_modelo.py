import sqlite3
from configuracao import BANCO_DE_DADOS
def obter_conexao_db():
    conn = sqlite3.connect(BANCO_DE_DADOS)
    conn.row_pactory = sqlite3.Row
    return conn

class PedidodModelo:
    @staticmethod
    def listar_produtos():
        # Obtém todos os produtps disponiveis no banco de dados
        conn = obter_conexao_db()
        cursor = conn.cursor()
        cursor.execute('SELECT id, nome, preco FROM produtos') # Apenas id, nome e preco 
        produtos = cursor.fetchall()
        conn.close()
        return [dict(produto)for produto in produtos]
    
    @staticmethod
    def criar_pedido(usuario_id,produto_id,quantidade):
        # Insere o pedido no banco de dados
        conn = obter_conexao_db()
        cursor = conn.cursor()
        cursor.execute('''
                       INSERT INTO pedidos (usuario_id, produto_id, quantidade)
                       VALUES (?,?,?)''',
                       (usuario_id,produto_id,quantidade))
        conn.commit()
        conn.close()
        