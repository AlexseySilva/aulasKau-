pip install flask

pip install flask-jwt-extended

pip install flask-mail

pip install flask-sqlalchemy




pip install sqlalchemy 

pip install flask-cors