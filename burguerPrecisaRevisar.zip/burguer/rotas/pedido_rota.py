from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from controladores.pedido_controlador import PedidoControlador

pedido_bp = Blueprint('pedido',__name__)

@pedido_bp.route('/produtos', methods=['GET'])
@jwt_required()
def listar_produtos():
    return jsonify(PedidoControlador.lista_opcoes())

@pedido_bp.route('/fazer', methods=['POST'])
@jwt_required()
def listar_produtos():
    return jsonify(PedidoControlador.fazer_pedido(request.get_json()))
