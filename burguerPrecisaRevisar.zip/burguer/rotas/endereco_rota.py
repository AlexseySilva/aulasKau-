from flask import Blueprint, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from controladores.endeco_controlador import EnderecoControlador

endereco_bp = Blueprint('enderecos',__name__)

@endereco_bp.route('/me',methods=['POST'])
@jwt_required()
def adicionar_endereco():
    dados = request.get_json()
    usuario_id = get_jwt_identity() # Obtém o ID do usuário autenticado
    return EnderecoControlador.adicionar_endereco() # Chama a função do controlador
