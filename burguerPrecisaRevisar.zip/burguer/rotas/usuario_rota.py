from flask import Blueprint, request, jsonify
from controladores.usuario_controlador import UsuarioControlador

usuario_bp = Blueprint('users', __name__)

@usuario_bp.route('/register', methods=['POST'])
def register():
    return jsonify(UsuarioControlador.registrar_usuario(request.get_json()))

# Rota para fazer login de um usuário
@usuario_bp.route('/login', methods=['POST'])
def login():
    return jsonify(UsuarioControlador.logar_usuario(request.get_json()))

