SECRET_KEY = 'your-secret_key' # Definindo uma chave secreta para a aplicação ( Essencial para criptografia e sessões)
JWT_SECRET_KEY = SECRET_KEY # Usando a mesma chave secreta para assinar os tokens JWT (JSON web token)
BANCO_DE_DADOS = 'users.db' # Definindo o nome do banco de dados SQLITE

# Configurações de e-mail para envio
MAIL_SERVER = 'smtp.gmail.com' # Servidor SMTP do Gmail para envio de e-mails
MAIL_PORT = 587 # Porta para envio de e-mails com TLS ( Tranport Layer Security)
MAIL_USERNAME = '''kb.santos7@gmail.com''' # Endereço de e-mail para enviar os e-mails ( substitua pelo seu e-mail)
MAIL_PASSWORD = '''cdtk bslt ffxs ugzc''' # Senha do aplicativo fo Gmail (gerada na configurações de segurança)
MAIL_USE_TLS = True# Habilita o uso de TLS ( protocolo de segurança ) ao enviar e-mails
MAIL_USE_SSL = False # Desabilita o uso de SSL ( Secure Scokets Layer) para e-mail

