from flask_jwt_extended import get_jwt_identity
from modelos.pedido_modelo import PedidodModelo # Verifique se o modelo está correto para pedidos

class PedidoControlador:
    @staticmethod
    def listar_opcoes():
        # Lista os produtos disponíveis para o pedido (nome e preço)
        produtos = PedidodModelo.listar_produtos() # Agora deve trazer apenas 'id', 'nome' e 'preco'
        return {"produtos_disponiveis": produtos},200
    
    @staticmethod
    def fazer_pedido(dados):
        usuario_id = get_jwt_identity()# Obtém o ID do usuário a partir do JWT
        produto_id = dados.get('produto_id')# Obtém o ID do produto do corpo da requisição
        quantidade = dados.get('quantidade',1)# Obtém a quantidade, default é 1 se não for passado

        # Verificação para garantir que produto_id e quantidade sejam válidos
        if not produto_id or quantidade <=0:
            return{"erro":"Produto e quantidade são obrigatórios"},400
        
        # Chama o modelo para criar o pedido
        PedidodModelo.criar_pedido(usuario_id, produto_id, quantidade)
        return{"mensagem":"Pedido realizado com sucesso"},201
    
    