from modelos.confirmacao_pedido_modelo import ConfirmacaoPedidoModelo
from utilitarios.envio_email import enviar_email

class ConfirmacaoPedidoControlador:
    @staticmethod
    def confirmar_pedido(usuario_id):
        # Confirma o pedido mais recente do usuário no banco de dados
        pedido = ConfirmacaoPedidoModelo.confirmar_pedido(usuario_id)

        if not pedido:
            return {"erro": "Pedido não encontrado ou não autorizado."}, 404

        # Verificando se a chave 'quantidade' existe no pedido
        if 'quantidade' not in pedido:
            return {"erro": "Informações do pedido estão incompletas"}, 400

        # Enviar e-mail de confirmação
        usuario_email = pedido['usuario_email']  # e-mail do usuario
        assunto = "Confirmação de pedido"

        # Corrigindo para incluir a quantidade de cada produto no pedido
        corpo = f'''
        Olá, seu pedido foi confirmado com sucesso!

        Detalhes do pedido:
        Produto(s): {pedido['produtos']}
        Quantidade: {pedido['quantidade']}
        Total: R$ {pedido['total']:.2f}

        O motoboy já saiu para a entrega e logo estará ai com seu pedido!

        Agradecemos pela compra e logo entraremos em contato com mais detalhes.

        Atenciosamente,

        BugBurger
        '''

        sucesso_email = enviar_email(usuario_email, assunto, corpo)

        if sucesso_email:
            return {"mensagem": "Pedido confirmado e e-mail enviado com sucesso"}, 200
        else:
            return {"erro": "Pedido confirmado, mas não foi possível enviar o e-mail."}, 500