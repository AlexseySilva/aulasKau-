import sqlite3
from configuracao import BANCO_DE_DADOS

def obter_conexao_db():
    conn = sqlite3.connect(BANCO_DE_DADOS)
    conn.row_factory = sqlite3.Row
    return conn

def criar_tabelas():
    conn = obter_conexao_db()
    cursor = conn.cursor()

    # Criando a tabela de usuários
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
                   id INTEGER PRIMARY KEY AUTOINCREMENT,
                   username TEXT UNIQUE NOT NULL,
                   password TEXT NOT NULL,
                   email TEXT UNIQUE NOT NULL
                   )
                ''')
    
    # Criando a tabela de produtos
    cursor.execute('''
            CREATE TABLE IF NOT EXISTS produtos(
                   id INTEGER PRIMARY KEY AUTOINCREMENT,
                   nome TEXT NOT NULL,
                   preco REAL NOT NULL
                   )
            ''')
    # Criando a tabela de pedidos com a coluna 'status
    cursor.execute('''
            CREATE TABLE IF NOT EXISTS pedidos (
                   id INTEGER PRIMARY KEY AUTOINCREMENTE,
                   usuario_id INTEGER,
                   produto_id INTEGER,
                   quantidade INTEGER,
                   status TEXT DEFAULT 'pendente',
                   FOREING KEY(usuario_id)REFERENCES users(id),
                   FOREING KEY(produto_id)REFERENCES produtos(id)
                   )
            ''') 
    
    # Criando a tabela de pagamentos
    cursor.execute('''
            CREATE TABLE IF NOT EXISTS pagamentos(
                   id INTEGER PRIMARY KEY AUTOINCREMENT,
                   usuario_id INTEGER,
                   tipo_pagamento TEXT NOT NULL,
                   status_pagamento TEXT NOT NULL,
                   FPREING KEY(usuario_id)REFERENCES users(id)
                   )
            ''')
    
    # Criando a tabela de endereçõs
    cursor.execute('''
            CREATE TABLE IF NOT EXISTS enderecos(
                   id INTEGER PRIMARY KEY AUTOINCREMENT,]
                   usuario_id INTEGER NOT NULL,
                   rua TEXT NOT NULL,
                   numero TEXT NOT NULL,
                   bairro TEXT NOT NULL,
                   cidade TEXT NOT NULL,
                   estado TEXT NOT NULL,
                   cep TEXT NOT NULL,
                   FOREIGN KEY(usuario_id)REFERENCES users(id)
                   )
            ''')
    # Inserindo produtos iniciais caso a tabela esteja vazia
    produtos_existem = cursor.execute('SELECT COUNT(*) FROM produtos').fetchone()[0]
    if produtos_existem == 0:
        cursor.executemany('''
                INSERT INTO produtos(nome.preco) VALUES (?.?)
                           ''',[
                               ('X-burguer',10.00)
                               ('Pizza',25.00)
                               ('Refrigerante',5.00)
                               ('Batata Frita',8.00)
                               ('Suco Natural',6.00)
                           ])