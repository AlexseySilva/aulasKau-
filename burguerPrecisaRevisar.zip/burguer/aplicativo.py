from flask import Flask
from flask_jwt_extended import JWTManager
from banco_dados.db import criar_tabelas
from rotas.usuario_rota import usuario_bp
from rotas.pedido_rota import pedido_bp
from rotas.endereco_rota import endereco_bp
from rotas.pagamento_rota import pagamento_bp
from rotas.confirmacao_pedido_rota import confirmacao_pedido_bp

# Cria a aplicação FLASK
app = Flask(__name__)
# Carrega as configurações do arquivo 'configuracao.py'
app.config.from_pyfile('configuracao')

# Inicializa o gerenciador JWT para autenticação
jwt = JWTManager(app)
# Criar as tabelas no banco de dados (caso ainda não existam)
criar_tabelas()

# Registra os blueprint com os respectivos prefixos de URL
app.register_blueprint(usuario_bp, url_prefix='/users') # Rota de usuário
app.register_blueprint(pedido_bp, url_prefix='/pedidos') # Rota de pedidos
app.register_blueprint(endereco_bp, url_prefix='/enderecos') # Rotas de enedereços
app.register_blueprint(pagamento_bp, url_prefix='/pagamentos') # Rota de pagamentos
app.register_blueprint(pedido_bp, url_prefix='/pedidos') # Rota de confirmaçao de pedidos



# Executa a aplicação em modo debug
if __name__=='__main__':
    app.run(debug=True)
